# KWG Sign-In Page

前端签到活动页面，支持套餐选择、补签、满签奖励等功能。可部署至 Vercel、Netlify 或在线预览于 StackBlitz。
