import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Gift, CalendarDays, PackageSearch, Undo2, BadgeCheck, Sparkles } from "lucide-react";

export default function SignInPageMobileUI() {
  // 省略...（此处插入全部 UI 内容，略）
  return <div className="p-4">...</div>;
}